import paramiko
import socket
import sys

filename = sys.argv[1]
cmdfile = sys.argv[2]

from getpass import getpass
password = getpass("Enter password: ")

with open(filename, 'rU') as input_file:

    for server in input_file.readlines():
        try:
            client = paramiko.SSHClient()
            client.load_system_host_keys()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            with open(cmdfile, 'rU') as cmd_file:

                for cmd in cmd_file.readlines():
                    client.connect(server.strip(), username='soprajap', password=password)
                     
                    stdin, stdout, stderr = client.exec_command(cmd)
                    for line in stdout:
                        print(line.strip('\n'))
                    client.close()
            
        except socket.gaierror:
            print('Unable to connect to %s.' % server)
            pass
